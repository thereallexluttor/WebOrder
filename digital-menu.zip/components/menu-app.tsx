"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ChefHat, Clock, Star } from "lucide-react"

const categories = [
  { id: "appetizers", name: "Appetizers", icon: "🥗" },
  { id: "pasta", name: "Pasta", icon: "🍝" },
  { id: "pizza", name: "Pizza", icon: "🍕" },
  { id: "mains", name: "Main Courses", icon: "🥩" },
  { id: "desserts", name: "Desserts", icon: "🍰" },
  { id: "drinks", name: "Drinks", icon: "🥤" },
]

const menuItems = {
  appetizers: [
    {
      id: 1,
      name: "Bruschetta Classica",
      description: "Toasted bread topped with fresh tomatoes, basil, and garlic",
      price: 8.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.8,
      prepTime: "10 min",
    },
    {
      id: 2,
      name: "Antipasto Platter",
      description: "Selection of cured meats, cheeses, olives, and roasted vegetables",
      price: 16.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.9,
      prepTime: "5 min",
    },
    {
      id: 3,
      name: "Arancini",
      description: "Crispy risotto balls filled with mozzarella and served with marinara",
      price: 12.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.7,
      prepTime: "15 min",
    },
  ],
  pasta: [
    {
      id: 4,
      name: "Spaghetti Carbonara",
      description: "Classic Roman pasta with eggs, pecorino cheese, and pancetta",
      price: 18.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.9,
      prepTime: "20 min",
    },
    {
      id: 5,
      name: "Penne Arrabbiata",
      description: "Spicy tomato sauce with garlic, red peppers, and fresh herbs",
      price: 16.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.6,
      prepTime: "18 min",
    },
    {
      id: 6,
      name: "Fettuccine Alfredo",
      description: "Creamy parmesan sauce with butter and fresh black pepper",
      price: 17.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.8,
      prepTime: "15 min",
    },
  ],
  pizza: [
    {
      id: 7,
      name: "Margherita",
      description: "San Marzano tomatoes, fresh mozzarella, basil, and olive oil",
      price: 14.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.8,
      prepTime: "25 min",
    },
    {
      id: 8,
      name: "Quattro Stagioni",
      description: "Four seasons pizza with artichokes, ham, mushrooms, and olives",
      price: 19.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.7,
      prepTime: "28 min",
    },
    {
      id: 9,
      name: "Diavola",
      description: "Spicy salami, mozzarella, tomato sauce, and chili oil",
      price: 17.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.9,
      prepTime: "25 min",
    },
  ],
  mains: [
    {
      id: 10,
      name: "Osso Buco",
      description: "Braised veal shanks with vegetables, white wine, and broth",
      price: 28.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.9,
      prepTime: "35 min",
    },
    {
      id: 11,
      name: "Branzino al Sale",
      description: "Mediterranean sea bass baked in sea salt with herbs",
      price: 24.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.8,
      prepTime: "30 min",
    },
  ],
  desserts: [
    {
      id: 12,
      name: "Tiramisu",
      description: "Classic Italian dessert with coffee-soaked ladyfingers and mascarpone",
      price: 8.9,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.9,
      prepTime: "5 min",
    },
    {
      id: 13,
      name: "Panna Cotta",
      description: "Silky vanilla custard with berry compote",
      price: 7.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.7,
      prepTime: "5 min",
    },
  ],
  drinks: [
    {
      id: 14,
      name: "Aperol Spritz",
      description: "Aperol, prosecco, and soda water with orange slice",
      price: 9.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.8,
      prepTime: "3 min",
    },
    {
      id: 15,
      name: "Italian Soda",
      description: "Sparkling water with your choice of syrup flavor",
      price: 4.5,
      image: "/placeholder.svg?height=120&width=120",
      rating: 4.5,
      prepTime: "2 min",
    },
  ],
}

export function MenuApp() {
  const [selectedCategory, setSelectedCategory] = useState("appetizers")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Bella Vista</h1>
              <p className="text-sm text-gray-600">Authentic Italian Cuisine</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Categories */}
        <div className="bg-white border-b">
          <ScrollArea className="w-full">
            <div className="flex gap-2 p-4 min-w-max">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  className={`flex items-center gap-2 whitespace-nowrap ${
                    selectedCategory === category.id ? "bg-orange-500 hover:bg-orange-600" : "hover:bg-gray-50"
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <span>{category.icon}</span>
                  {category.name}
                </Button>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Menu Items */}
        <div className="p-4">
          <div className="grid gap-4">
            {menuItems[selectedCategory as keyof typeof menuItems]?.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <CardContent className="p-0">
                  <div className="flex gap-4 p-4">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-900 text-lg">{item.name}</h3>
                        <div className="text-right">
                          <div className="text-lg font-bold text-gray-900">${item.price}</div>
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm mb-3 leading-relaxed">{item.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span>{item.rating}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{item.prepTime}</span>
                        </div>
                      </div>
                    </div>
                    <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
