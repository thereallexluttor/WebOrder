"use client"

import { useEffect, useState } from "react"
import { ChefHat } from "lucide-react"

export function SplashScreen() {
  const [fadeIn, setFadeIn] = useState(false)

  useEffect(() => {
    setFadeIn(true)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 flex items-center justify-center">
      <div
        className={`text-center transition-all duration-1000 ${fadeIn ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
      >
        <div className="mb-8">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-2xl">
            <ChefHat className="w-12 h-12 text-orange-500" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">Bella Vista</h1>
          <p className="text-white/80 text-lg">Authentic Italian Cuisine</p>
        </div>
        <div className="flex justify-center">
          <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
        </div>
      </div>
    </div>
  )
}
